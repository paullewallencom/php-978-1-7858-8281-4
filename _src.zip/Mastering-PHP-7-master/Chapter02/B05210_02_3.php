<?php

class Foggyline_User_Model
{
 // body
}
