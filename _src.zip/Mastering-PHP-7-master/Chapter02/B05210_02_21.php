<?php

class Logger
{
  public function log($msg, $code)
  {
    if ($code === 500)
    {
     // logic
    }
    elseif ($code === 600)
    {
    // logic
    }
    elseif ($code === 700)
    {
    // logic
    }
    else
    {
    // logic
    }
  }
}
