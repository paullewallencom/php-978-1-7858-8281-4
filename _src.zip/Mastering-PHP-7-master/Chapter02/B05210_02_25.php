\<NamespaceName>(\<SubNamespaceNames>)*\<ClassName>
