<?php

namespace Foggyline\Model;

class User
{
 // body
}
