<?php

class XmlParser
{
 // body
}

class XMLParser
{
 // body
}
