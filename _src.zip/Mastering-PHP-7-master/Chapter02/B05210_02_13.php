<?php

class Employee {
 // body
}
