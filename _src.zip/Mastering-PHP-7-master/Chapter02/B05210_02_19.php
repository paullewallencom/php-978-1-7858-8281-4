<?php

class Logger
{
  public function log($msg, $code)
  {
    if($code >= 500) {
    // logic
    }
  }
}
