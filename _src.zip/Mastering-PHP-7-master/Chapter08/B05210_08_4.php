serverless install --url https://github.com/ZeroSharp/serverless-php
