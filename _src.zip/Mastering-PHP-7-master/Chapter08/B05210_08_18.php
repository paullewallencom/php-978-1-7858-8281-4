docker run --rm -it -e "PAYLOAD_FILE=greet.payload.json" ajzele/greet:0.0.1
