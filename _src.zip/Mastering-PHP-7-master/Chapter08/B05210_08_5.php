php index.php
serverless invoke local --function hello
