sudo npm install -g serverless
serverless --version
