docker build -t ajzele/greet:0.0.1 .
