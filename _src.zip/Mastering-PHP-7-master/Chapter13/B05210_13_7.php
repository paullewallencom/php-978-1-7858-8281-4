composer require symfony/dependency-injection
