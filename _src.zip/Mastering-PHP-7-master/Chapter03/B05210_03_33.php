Caught: Return value of hello() must be of the type string, integer returned
