    try {
      //...
    }
    catch (\Exception $e) {
      $messages[] = __('We can't add this item to your shopping cart right now.');
    }
