    try {
      //...
    }
    catch (\Exception $e) {
      app_error_log($e);
    }
