Caught: syntax error, unexpected 'M' (T_STRING), expecting ',' or ')'
