"autoload": {
  "psr-4": {
    "FoggylineMP7": "src/Foggyline/MP7/"
  }
}
