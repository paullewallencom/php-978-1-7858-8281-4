start
6
12
18
end
