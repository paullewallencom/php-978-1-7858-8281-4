<phpunit bootstrap="autoload.php">
<testsuites>
<testsuite name="foggyline">
<directory>src/Foggyline/*/Test/Unit/*</directory>
</testsuite>
</testsuites>
</phpunit>
