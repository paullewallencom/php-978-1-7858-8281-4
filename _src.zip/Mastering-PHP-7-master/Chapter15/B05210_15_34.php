phpspec describe Foggyline/Checkout/Model/Guest/Cart
