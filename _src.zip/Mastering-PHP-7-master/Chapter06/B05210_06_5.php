<?php

interface User {}
interface Employee extends User {}
