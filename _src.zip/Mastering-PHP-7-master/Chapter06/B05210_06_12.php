key: name, value: John
key: age, value: 34
key: salary, value: 4200
