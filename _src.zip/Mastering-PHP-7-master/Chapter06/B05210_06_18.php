<?php

trait Formatter
{
  // Trait body
}
