Iterator extends Traversable {
  abstract public mixed current(void)
  abstract public scalar key(void)
  abstract public void next(void)
  abstract public void rewind(void)
  abstract public boolean valid(void)
}
