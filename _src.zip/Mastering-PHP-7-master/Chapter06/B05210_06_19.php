class Ups
{
  use Formatter;

  // Class body (properties & methods)
}
