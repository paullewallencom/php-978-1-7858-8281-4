Function [ <internal:standard> function str_replace ] {
  - Parameters [4] {
     Parameter #0 [ <required> $search ]
     Parameter #1 [ <required> $replace ]
     Parameter #2 [ <required> $subject ]
     Parameter #3 [ <optional> &$replace_count ]
  }
}
