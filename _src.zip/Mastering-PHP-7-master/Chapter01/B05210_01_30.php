function import(iterable $users)
 {
   // ...
 }

function import(iterable $users = null)
 {
   // ...
 }

function import(iterable $users = [])
 {
   // ...
 }
