try {
      // ...
    }
catch (\InvalidArgumentException $e)
    {
      // ...
    }
catch (\LengthException $e)
    {
      // ...
    }
catch (Exception $e)
   {
     // ...
   }
finally
  {
    // ...
  }
