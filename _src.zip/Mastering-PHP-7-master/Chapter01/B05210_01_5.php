function register(string $user, int $age) : bool {
  // logic ...
  return true;
}
