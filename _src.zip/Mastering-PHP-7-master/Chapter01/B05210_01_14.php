(expr) <=> (expr)
