<?xml version="1.0" ?>
<definitions>
<types>
<!-- ... -->
    </types>
<message>
<!-- ... -->
    </message>
<portType>
<!-- ... -->
    </portType>
<binding>
<!-- ... -->
    </binding>
<port>
<!-- ... -->
    </port>
<service>
<!-- ... -->
    </service>
</definitions>
