./configure
make
make install
