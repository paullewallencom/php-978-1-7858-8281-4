thrift -version
