<?xml version="1.0" ?>
<env:Envelope>
<env:Header>
<!-- ... -->
    </env:Header>
<env:Body>
<!-- ... -->
        <env:Fault>
<!-- ... -->
        </env:Fault>
</env:Body>
</env:Envelope>
