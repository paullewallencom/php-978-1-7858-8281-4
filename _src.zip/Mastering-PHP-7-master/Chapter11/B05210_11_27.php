$app->get('/resource/path', function () { /* todo: logic */ });
$app->post('/resource/path', function () { /* todo: logic */ });
$app->put('/resource/path', function () { /* todo: logic */ });
$app->delete('/resource/path', function () { /* todo: logic */ });
$app->patch('/resource/path', function () { /* todo: logic */ });
$app->options('/resource/path', function () { /* todo: logic */ });
