sudo apt-get -y install php7.0-cli php7.0-mysql
