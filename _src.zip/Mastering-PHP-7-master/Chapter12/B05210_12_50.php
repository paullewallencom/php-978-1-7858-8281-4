$client->set('test', 'test2', 3600);
