sudo apt-get -y install composer
composer require mongodb/mongodb
