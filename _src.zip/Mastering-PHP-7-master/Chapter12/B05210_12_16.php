ALTER TABLE customer ADD INDEX idx_email (email);
