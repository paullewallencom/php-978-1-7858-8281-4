No index used in query/prepared statement SELECT * FROM customer WHERE email = "MARIA.MILLER@sakilacustomer.org"
