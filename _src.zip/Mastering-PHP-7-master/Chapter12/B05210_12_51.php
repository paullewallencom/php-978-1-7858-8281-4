$client->setex('key', 3600, 'value');
