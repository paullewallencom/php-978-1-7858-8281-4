DROP SCHEMA IF EXISTS sakila;
CREATE SCHEMA sakila;
USE sakila;
