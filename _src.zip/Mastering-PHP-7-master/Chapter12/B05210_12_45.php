<?php

$client = new Redis();

$client->connect('localhost', 6379);
