<?php
// script.php
sleep(25);
echo 'Test#2';
