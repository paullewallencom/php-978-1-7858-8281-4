array(2) {
  ["photo"] => array(5) {
    ["name"] => string(9) "photo.jpg"
    ["type"] => string(10) "image/jpeg"
    ["tmp_name"] => string(14) "/tmp/phpGutI91"
    ["error"] => int(0)
    ["size"] => int(42497)
  }
  ["article"] => array(5) {
    ["name"] => string(11) "article.pdf"
    ["type"] => string(15) "application/pdf"
    ["tmp_name"] => string(14) "/tmp/phpxsnx1e"
    ["error"] => int(0)
    ["size"] => int(433176)
  }
}
