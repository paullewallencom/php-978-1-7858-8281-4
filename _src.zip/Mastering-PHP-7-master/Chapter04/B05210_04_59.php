static object __set_state(array $properties)
