John, age 34
