__call => hello: John, 34
bonus: 560
__call => salary: 4200
