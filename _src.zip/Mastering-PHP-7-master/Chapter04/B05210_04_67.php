array __debugInfo(void)
