User::hello('John', 34);
User::bonus(560.00);
User::salary(4200.00);
