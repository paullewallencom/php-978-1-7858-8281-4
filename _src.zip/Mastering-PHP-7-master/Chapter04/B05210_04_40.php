object(User)#1 (1) {
  ["data":"User":private]=> array(2) {
    ["name"]=> string(4) "John"
    ["age"]=> int(34)
  }
}

object(User)#1 (1) {
  ["data":"User":private]=> array(1) {
    ["name"]=> string(4) "John"
  }
}
