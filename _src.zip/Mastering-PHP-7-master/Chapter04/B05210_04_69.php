object(User)#1 (2) {
  ["name"]=> string(4) "John"
  ["income"]=> float(4880)
}
