<?php

class User
{
   public function __destruct()
   {
      echo '__destruct';
   }
}
