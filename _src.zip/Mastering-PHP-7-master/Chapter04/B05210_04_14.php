echo 'A';
new User();
echo 'B';

// outputs "A__destructB"
