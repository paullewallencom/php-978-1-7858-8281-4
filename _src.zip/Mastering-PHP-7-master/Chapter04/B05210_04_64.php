void __clone(void)
