object(Backup)#1 (4) {
  ["ftpClient":protected]=> resource(4) of type (FTP Buffer)
  ["ftpHost":protected]=> string(14) "test.rebex.net"
  ["ftpUser":protected]=> string(4) "demo"
  ["ftpPass":protected]=> string(8) "password"
}

string(119) "O:6:"Backup":3:{s:10:"*ftpHost";s:14:"test.rebex.net";s:10:"*ftpUser";s:4:"demo";s:10:"*ftpPass";s:8:"password";}"

object(Backup)#2 (4) {
  ["ftpClient":protected]=> resource(5) of type (FTP Buffer)
  ["ftpHost":protected]=> string(14) "test.rebex.net"
  ["ftpUser":protected]=> string(4) "demo"
  ["ftpPass":protected]=> string(8) "password"
}
